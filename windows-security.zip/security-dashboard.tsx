"use client"

import { useState } from "react"
import {
  Shield,
  AlertTriangle,
  Check,
  X,
  RefreshCw,
  Lock,
  Wifi,
  HardDrive,
  FileWarning,
  Clock,
  Settings,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function SecurityDashboard() {
  const [securityScore, setSecurityScore] = useState(85)
  const [isScanning, setIsScanning] = useState(false)

  const startScan = () => {
    setIsScanning(true)
    setTimeout(() => {
      setIsScanning(false)
      setSecurityScore(Math.floor(Math.random() * 15) + 80) // Random score between 80-95
    }, 3000)
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 dark:bg-slate-950">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6 dark:border-slate-800">
        <div className="flex items-center gap-2 font-semibold">
          <Shield className="h-6 w-6 text-blue-500" />
          <span>Windows Security Center</span>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <Button variant="outline" size="sm" onClick={() => startScan()} disabled={isScanning}>
            {isScanning ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Scanning...
              </>
            ) : (
              "Quick Scan"
            )}
          </Button>
          <Button variant="ghost" size="icon">
            <Settings className="h-5 w-5" />
            <span className="sr-only">Settings</span>
          </Button>
        </div>
      </header>

      <main className="flex-1 p-6">
        <div className="mx-auto max-w-6xl space-y-6">
          <div className="flex flex-col gap-4 md:flex-row">
            <Card className="flex-1">
              <CardHeader className="pb-2">
                <CardTitle>Security Status</CardTitle>
                <CardDescription>Overall system protection</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center gap-4">
                  <div className="relative flex h-32 w-32 items-center justify-center rounded-full border-8 border-slate-100 dark:border-slate-800">
                    <div className="text-center">
                      <span className="text-3xl font-bold">{securityScore}</span>
                      <span className="text-sm">/100</span>
                    </div>
                    <svg className="absolute -rotate-90" width="128" height="128" viewBox="0 0 128 128">
                      <circle cx="64" cy="64" r="56" fill="none" stroke="#e2e8f0" strokeWidth="12" />
                      <circle
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        stroke={securityScore > 90 ? "#10b981" : securityScore > 70 ? "#f59e0b" : "#ef4444"}
                        strokeWidth="12"
                        strokeDasharray="352"
                        strokeDashoffset={352 - (352 * securityScore) / 100}
                      />
                    </svg>
                  </div>
                  <div className="text-center">
                    {securityScore > 90 ? (
                      <Badge className="bg-green-500">Protected</Badge>
                    ) : securityScore > 70 ? (
                      <Badge className="bg-amber-500">Attention Needed</Badge>
                    ) : (
                      <Badge className="bg-red-500">At Risk</Badge>
                    )}
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  View Details
                </Button>
              </CardFooter>
            </Card>

            <Card className="flex-1">
              <CardHeader className="pb-2">
                <CardTitle>Protection Status</CardTitle>
                <CardDescription>Security features status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Lock className="h-5 w-5 text-green-500" />
                      <span>Firewall</span>
                    </div>
                    <Badge
                      variant="outline"
                      className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
                    >
                      <Check className="mr-1 h-3 w-3" /> Active
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-green-500" />
                      <span>Antivirus</span>
                    </div>
                    <Badge
                      variant="outline"
                      className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
                    >
                      <Check className="mr-1 h-3 w-3" /> Active
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Wifi className="h-5 w-5 text-amber-500" />
                      <span>Network Protection</span>
                    </div>
                    <Badge
                      variant="outline"
                      className="bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300"
                    >
                      <AlertTriangle className="mr-1 h-3 w-3" /> Warning
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <HardDrive className="h-5 w-5 text-green-500" />
                      <span>Disk Encryption</span>
                    </div>
                    <Badge
                      variant="outline"
                      className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
                    >
                      <Check className="mr-1 h-3 w-3" /> Active
                    </Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Configure
                </Button>
              </CardFooter>
            </Card>
          </div>

          <Tabs defaultValue="threats">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="threats">Threats</TabsTrigger>
              <TabsTrigger value="updates">Updates</TabsTrigger>
              <TabsTrigger value="firewall">Firewall</TabsTrigger>
            </TabsList>
            <TabsContent value="threats" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Threat Detections</CardTitle>
                  <CardDescription>Threats detected in the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-lg border p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileWarning className="h-5 w-5 text-red-500" />
                          <div>
                            <p className="font-medium">Potential Unwanted Application</p>
                            <p className="text-sm text-muted-foreground">File: setup_cracked.exe</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">Quarantined</Badge>
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">2 days ago</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileWarning className="h-5 w-5 text-amber-500" />
                          <div>
                            <p className="font-medium">Suspicious Script</p>
                            <p className="text-sm text-muted-foreground">File: invoice_document.js</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">Removed</Badge>
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">1 week ago</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileWarning className="h-5 w-5 text-amber-500" />
                          <div>
                            <p className="font-medium">Tracking Cookie</p>
                            <p className="text-sm text-muted-foreground">Domain: analytics-tracker.com</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">Blocked</Badge>
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">2 weeks ago</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    View All Threats
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            <TabsContent value="updates" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Security Updates</CardTitle>
                  <CardDescription>System and definition updates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="mb-2 flex items-center justify-between">
                        <span className="font-medium">Virus Definitions</span>
                        <span className="text-sm text-green-600 dark:text-green-400">Up to date</span>
                      </div>
                      <div className="text-sm text-muted-foreground">Last updated: Today, 09:45 AM</div>
                      <Progress value={100} className="mt-2 h-2" />
                    </div>

                    <div>
                      <div className="mb-2 flex items-center justify-between">
                        <span className="font-medium">Security Intelligence</span>
                        <span className="text-sm text-green-600 dark:text-green-400">Up to date</span>
                      </div>
                      <div className="text-sm text-muted-foreground">Last updated: Yesterday, 11:30 PM</div>
                      <Progress value={100} className="mt-2 h-2" />
                    </div>

                    <div>
                      <div className="mb-2 flex items-center justify-between">
                        <span className="font-medium">Windows Security Updates</span>
                        <span className="text-sm text-amber-600 dark:text-amber-400">Update available</span>
                      </div>
                      <div className="text-sm text-muted-foreground">KB5023778 pending installation</div>
                      <Progress value={70} className="mt-2 h-2" />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Install Updates</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            <TabsContent value="firewall" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Firewall Status</CardTitle>
                  <CardDescription>Network protection settings</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border p-3">
                      <div>
                        <p className="font-medium">Domain Network</p>
                        <p className="text-sm text-muted-foreground">Corporate network connections</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
                      >
                        <Check className="mr-1 h-3 w-3" /> Enabled
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-3">
                      <div>
                        <p className="font-medium">Private Network</p>
                        <p className="text-sm text-muted-foreground">Home or work network connections</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
                      >
                        <Check className="mr-1 h-3 w-3" /> Enabled
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-3">
                      <div>
                        <p className="font-medium">Public Network</p>
                        <p className="text-sm text-muted-foreground">Public locations like airports and cafes</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
                      >
                        <Check className="mr-1 h-3 w-3" /> Enabled
                      </Badge>
                    </div>

                    <div className="mt-4">
                      <p className="mb-2 font-medium">Recent Connection Attempts Blocked</p>
                      <div className="rounded-lg border">
                        <div className="border-b p-3">
                          <div className="flex items-center justify-between">
                            <span>192.168.1.45</span>
                            <span className="text-sm text-muted-foreground">Port 445</span>
                          </div>
                        </div>
                        <div className="border-b p-3">
                          <div className="flex items-center justify-between">
                            <span>45.33.100.12</span>
                            <span className="text-sm text-muted-foreground">Port 80</span>
                          </div>
                        </div>
                        <div className="p-3">
                          <div className="flex items-center justify-between">
                            <span>104.28.16.92</span>
                            <span className="text-sm text-muted-foreground">Port 443</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    Firewall Settings
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Security Recommendations</CardTitle>
                <CardDescription>Improve your system security</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="mt-0.5 h-5 w-5 text-amber-500" />
                    <div>
                      <p className="font-medium">Enable two-factor authentication</p>
                      <p className="text-sm text-muted-foreground">
                        Add an extra layer of security to your Microsoft account
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="mt-0.5 h-5 w-5 text-amber-500" />
                    <div>
                      <p className="font-medium">Update browser extensions</p>
                      <p className="text-sm text-muted-foreground">
                        Some extensions are out of date and may pose security risks
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="mt-0.5 h-5 w-5 text-amber-500" />
                    <div>
                      <p className="font-medium">Configure automatic backups</p>
                      <p className="text-sm text-muted-foreground">Protect your data from ransomware attacks</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Apply Recommendations
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Security History</CardTitle>
                <CardDescription>Recent security events</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100 dark:bg-green-900">
                      <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <p className="font-medium">Quick scan completed</p>
                      <p className="text-sm text-muted-foreground">Today, 10:15 AM</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
                      <RefreshCw className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="font-medium">Virus definitions updated</p>
                      <p className="text-sm text-muted-foreground">Today, 09:45 AM</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900">
                      <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                    </div>
                    <div>
                      <p className="font-medium">Suspicious connection blocked</p>
                      <p className="text-sm text-muted-foreground">Yesterday, 08:30 PM</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-red-100 dark:bg-red-900">
                      <X className="h-4 w-4 text-red-600 dark:text-red-400" />
                    </div>
                    <div>
                      <p className="font-medium">Malware removed</p>
                      <p className="text-sm text-muted-foreground">3 days ago, 02:15 PM</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  View Full History
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

