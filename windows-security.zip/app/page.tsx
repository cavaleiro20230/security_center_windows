"use client"

import SecurityDashboard from "../security-dashboard"

export default function SyntheticV0PageForDeployment() {
  return <SecurityDashboard />
}